class Piece:
    def __init__(self) -> None:
        pass